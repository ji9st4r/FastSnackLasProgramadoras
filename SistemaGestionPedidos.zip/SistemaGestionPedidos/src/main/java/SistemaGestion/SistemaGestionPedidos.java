/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SistemaGestion;

import formularios.FrmInicio;

/**
 *
 * @author Dhamar Aldana
 */
public class SistemaGestionPedidos {
    public static void main(String[] args) {
        System.out.println("Sistema Activo");
        
        FrmInicio inicio = new FrmInicio();
        inicio.setLocationRelativeTo(null);
        inicio.setVisible(true);
    }
}
