/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelos.Producto;

/**
 *
 * @author Dhamar Aldana
 */
public class ProductoDAO {

    public void guardarProducto(Producto producto) {

        String sql = "INSERT INTO productos(nombre, precio) VALUES (?, ?)";

        try (Connection conexion = ConexionBD.conectar(); PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, producto.getNombre());
            ps.setDouble(2, producto.getPrecio());

            ps.executeUpdate();

            System.out.println("Producto guardado correctamente");

        } catch (SQLException e) {

            System.out.println("Error al guardar producto: "
                    + e.getMessage());
        }
    }

    public ResultSet mostrarProductos() {
        ResultSet rs = null;
        String sql = "SELECT * FROM productos";
        try {
            Connection conexion = ConexionBD.conectar();
            PreparedStatement ps
                    = conexion.prepareStatement(sql);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            System.out.println(
                    "Error al mostrar productos: "
                    + e.getMessage()
            );
        }
        return rs;
    }

    public ResultSet buscarProducto(int idProducto) {
        ResultSet rs = null;
        String sql = "SELECT * FROM productos "
                + "WHERE idProducto = ?";
        try {
            Connection conexion = ConexionBD.conectar();
            PreparedStatement ps
                    = conexion.prepareStatement(sql);
            ps.setInt(1, idProducto);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            System.out.println(
                    "Error al buscar producto: "
                    + e.getMessage()
            );
        }
        return rs;
    }

    public void editarProducto(Producto producto) {
        String sql = "UPDATE productos "
                + "SET nombre = ?, precio = ? "
                + "WHERE idProducto = ?";
        try (
                Connection conexion = ConexionBD.conectar(); PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, producto.getNombre());
            ps.setDouble(2, producto.getPrecio());
            ps.setInt(3, producto.getIdProducto());
            ps.executeUpdate();

            System.out.println(
                    "Producto actualizado correctamente"
            );
        } catch (SQLException e) {
            System.out.println(
                    "Error al editar producto: "
                    + e.getMessage()
            );
        }
    }

    public void eliminarProducto(int idProducto) {
        String sql = "DELETE FROM productos "
                + "WHERE idProducto = ?";
        try (
                Connection conexion = ConexionBD.conectar(); PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idProducto);
            ps.executeUpdate();
            System.out.println(
                    "Producto eliminado correctamente"
            );
        } catch (SQLException e) {
            System.out.println(
                    "Error al eliminar producto: "
                    + e.getMessage()
            );
        }
    }
}
